package org.example.logitrackback.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.example.logitrackback.entity.Client;
import org.example.logitrackback.service.ClientService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/clients")
@RequiredArgsConstructor
public class ClientController {

    private final ClientService clientService;

    /**
     * POST /api/clients
     * Body : { "nom": "Alice", "email": "alice@mail.com", "telephone": "0612345678", "ville": "Casablanca" }
     */
    @PostMapping
    public ResponseEntity<Client> creerClient(@Valid @RequestBody Client client) {
        Client nouveau = clientService.creerClient(client);
        return ResponseEntity.status(HttpStatus.CREATED).body(nouveau);
    }

    /**
     * GET /api/clients
     */
    @GetMapping
    public ResponseEntity<List<Client>> getAllClients() {
        return ResponseEntity.ok(clientService.getAllClients());
    }

    /**
     * GET /api/clients/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<Client> getClientById(@PathVariable Long id) {
        return ResponseEntity.ok(clientService.getClientById(id));
    }

    /**
     * DELETE /api/clients/{id}
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> supprimerClient(@PathVariable Long id) {
        clientService.supprimerClient(id);
        return ResponseEntity.noContent().build();
    }
}
