package org.example.logitrackback.service;

import org.example.logitrackback.entity.Produit;
import org.example.logitrackback.exception.ResourceNotFoundException;
import org.example.logitrackback.repository.ProduitRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class ProduitService {

    private final ProduitRepository produitRepository;

    // Seuil de stock faible (peut être externalisé dans application.properties)
    private static final int SEUIL_STOCK_FAIBLE = 10;

    public Produit creerProduit(Produit produit) {
        return produitRepository.save(produit);
    }

    @Transactional(readOnly = true)
    public List<Produit> getAllProduits() {
        return produitRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Produit getProduitById(Long id) {
        return produitRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Produit", id));
    }

    public void supprimerProduit(Long id) {
        if (!produitRepository.existsById(id)) {
            throw new ResourceNotFoundException("Produit", id);
        }
        produitRepository.deleteById(id);
    }

    // ── Derived Query ──────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public List<Produit> getProduitsByCategorie(String categorie) {
        return produitRepository.findByCategorieIgnoreCase(categorie);
    }

    @Transactional(readOnly = true)
    public List<Produit> getProduitsByPrixMax(BigDecimal prixMax) {
        return produitRepository.findByPrixLessThan(prixMax);
    }

    // ── @Query ─────────────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public List<Produit> getProduitsStockFaible() {
        return produitRepository.findLowStockProducts(SEUIL_STOCK_FAIBLE);
    }
}
