package org.example.logitrackback.controller;


import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.example.logitrackback.entity.Commande;
import org.example.logitrackback.entity.LigneCommande;
import org.example.logitrackback.enums.StatutCommande;
import org.example.logitrackback.service.CommandeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class CommandeController {

    private final CommandeService commandeService;


    public record CreerCommandeRequest(
            @NotNull(message = "Le clientId est obligatoire") Long clientId
    ) {}

    public record AjouterProduitRequest(
            @NotNull(message = "Le produitId est obligatoire") Long produitId,
            @NotNull @Min(1) Integer quantite
    ) {}

    public record ModifierStatutRequest(
            @NotNull(message = "Le statut est obligatoire") StatutCommande statut
    ) {}


    @PostMapping
    public ResponseEntity<Commande> creerCommande(@Valid @RequestBody CreerCommandeRequest request) {
        Commande commande = commandeService.creerCommande(request.clientId());
        return ResponseEntity.status(HttpStatus.CREATED).body(commande);
    }

    /**
     * POST /api/orders/{orderId}/products
     * Body : { "produitId": 2, "quantite": 3 }
     */
    @PostMapping("/{orderId}/products")
    public ResponseEntity<LigneCommande> ajouterProduit(
            @PathVariable Long orderId,
            @Valid @RequestBody AjouterProduitRequest request) {
        LigneCommande ligne = commandeService.ajouterProduitACommande(
                orderId, request.produitId(), request.quantite());
        return ResponseEntity.status(HttpStatus.CREATED).body(ligne);
    }

    /**
     * GET /api/orders
     */
    @GetMapping
    public ResponseEntity<List<Commande>> getAllCommandes() {
        return ResponseEntity.ok(commandeService.getAllCommandes());
    }

    /**
     * GET /api/orders/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<Commande> getCommandeById(@PathVariable Long id) {
        return ResponseEntity.ok(commandeService.getCommandeById(id));
    }

    /**
     * PUT /api/orders/{id}/status
     * Body : { "statut": "EXPEDIEE" }
     */
    @PutMapping("/{id}/status")
    public ResponseEntity<Commande> modifierStatut(
            @PathVariable Long id,
            @Valid @RequestBody ModifierStatutRequest request) {
        Commande commande = commandeService.modifierStatut(id, request.statut());
        return ResponseEntity.ok(commande);
    }

    // ── Derived Query ──────────────────────────────────────────────────────────

    /**
     * GET /api/orders/client/{clientId}
     */
    @GetMapping("/client/{clientId}")
    public ResponseEntity<List<Commande>> getCommandesByClient(@PathVariable Long clientId) {
        return ResponseEntity.ok(commandeService.getCommandesByClient(clientId));
    }

    // ── @Query ─────────────────────────────────────────────────────────────────

    /**
     * GET /api/orders/count
     */
    @GetMapping("/count")
    public ResponseEntity<Map<String, Long>> countCommandes() {
        return ResponseEntity.ok(Map.of("totalCommandes", commandeService.countCommandes()));
    }
}
