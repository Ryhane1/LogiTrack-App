package org.example.logitrackback.controller;

import lombok.RequiredArgsConstructor;
import org.example.logitrackback.service.CommandeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/statistics")
@RequiredArgsConstructor
public class StatisticsController {

    private final CommandeService commandeService;


    @GetMapping("/top-product")
    public ResponseEntity<Object> getTopProduct() {
        return ResponseEntity.ok(commandeService.getTopProduct());
    }
}
