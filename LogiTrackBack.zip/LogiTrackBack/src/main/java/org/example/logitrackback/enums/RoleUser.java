package org.example.logitrackback.enums;

public enum RoleUser {
    ADMIN,
    MEDECIN,
    PATIENT
}
