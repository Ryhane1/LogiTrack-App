package org.example.logitrackback.controller;


import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.example.logitrackback.entity.Produit;
import org.example.logitrackback.service.ProduitService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
public class ProduitController {

    private final ProduitService produitService;

    /**
     * POST /api/products
     * Body : { "nom": "Laptop", "categorie": "Informatique", "prix": 8500.00, "quantiteStock": 25 }
     */
    @PostMapping
    public ResponseEntity<Produit> creerProduit(@Valid @RequestBody Produit produit) {
        Produit nouveau = produitService.creerProduit(produit);
        return ResponseEntity.status(HttpStatus.CREATED).body(nouveau);
    }

    /**
     * GET /api/products
     */
    @GetMapping
    public ResponseEntity<List<Produit>> getAllProduits() {
        return ResponseEntity.ok(produitService.getAllProduits());
    }

    /**
     * GET /api/products/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<Produit> getProduitById(@PathVariable Long id) {
        return ResponseEntity.ok(produitService.getProduitById(id));
    }

    /**
     * DELETE /api/products/{id}
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> supprimerProduit(@PathVariable Long id) {
        produitService.supprimerProduit(id);
        return ResponseEntity.noContent().build();
    }

    // ── Derived Query ──────────────────────────────────────────────────────────

    /**
     * GET /api/products/category/{category}
     * Exemple : GET /api/products/category/Informatique
     */
    @GetMapping("/category/{category}")
    public ResponseEntity<List<Produit>> getByCategorie(@PathVariable String category) {
        return ResponseEntity.ok(produitService.getProduitsByCategorie(category));
    }

    /**
     * GET /api/products/price/{price}
     * Exemple : GET /api/products/price/500.00
     */
    @GetMapping("/price/{price}")
    public ResponseEntity<List<Produit>> getByPrixMax(@PathVariable BigDecimal price) {
        return ResponseEntity.ok(produitService.getProduitsByPrixMax(price));
    }

    // ── @Query ─────────────────────────────────────────────────────────────────

    /**
     * GET /api/products/low-stock
     * Retourne les produits avec un stock < 10 unités
     */
    @GetMapping("/low-stock")
    public ResponseEntity<List<Produit>> getStockFaible() {
        return ResponseEntity.ok(produitService.getProduitsStockFaible());
    }
}
