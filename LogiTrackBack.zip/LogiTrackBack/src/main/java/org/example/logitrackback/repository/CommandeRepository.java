package org.example.logitrackback.repository;

import org.example.logitrackback.entity.Commande;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CommandeRepository extends JpaRepository<Commande, Long> {

    // ── Derived Query ──────────────────────────────────────────────────────────

    /**
     * Recherche toutes les commandes d'un client donné.
     * GET /api/orders/client/{clientId}
     */
    List<Commande> findByClientId(Long clientId);

    // ── @Query ─────────────────────────────────────────────────────────────────

    /**
     * Nombre total de commandes dans le système.
     * GET /api/orders/count
     */
    @Query("SELECT COUNT(c) FROM Commande c")
    long countTotalCommandes();
}
