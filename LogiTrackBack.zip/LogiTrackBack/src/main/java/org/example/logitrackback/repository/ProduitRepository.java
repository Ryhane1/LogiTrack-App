package org.example.logitrackback.repository;

import org.example.logitrackback.entity.Produit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface ProduitRepository extends JpaRepository<Produit, Long> {

    // ── Derived Query ──────────────────────────────────────────────────────────

    /**
     * Recherche les produits par catégorie (insensible à la casse).
     * GET /api/products/category/{category}
     */
    List<Produit> findByCategorieIgnoreCase(String categorie);

    /**
     * Recherche les produits dont le prix est inférieur à la valeur donnée.
     * GET /api/products/price/{price}
     */
    List<Produit> findByPrixLessThan(BigDecimal prix);

    // ── @Query ─────────────────────────────────────────────────────────────────

    /**
     * Retourne les produits dont le stock est faible (< 10 unités).
     * GET /api/products/low-stock
     */
    @Query("SELECT p FROM Produit p WHERE p.quantiteStock < :seuil ORDER BY p.quantiteStock ASC")
    List<Produit> findLowStockProducts(@Param("seuil") int seuil);
}
